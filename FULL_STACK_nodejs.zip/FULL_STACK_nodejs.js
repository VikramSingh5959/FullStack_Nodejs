const express = require("express");
const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory users array
let users = [];

// ----------- MIDDLEWARE -----------
app.use((req, res, next) => {
  const time = new Date().toLocaleString();
  console.log(`Request received at: ${time}`);
  console.log(`${req.method} ${req.url}`);
  next();
});

// ----------- ROOT ROUTE -----------
app.get("/", (req, res) => {
  res.json({
    message: "Server Running",
    time: new Date().toLocaleString()
  });
});

// ----------- GET ALL USERS -----------
app.get("/users", (req, res) => {
  res.json({
    message: "Users fetched",
    data: users,
    time: new Date().toLocaleString()
  });
});

// ----------- ADD USER -----------
app.post("/users", (req, res) => {
  const { name, email } = req.body;

  if (!name || !email) {
    return res.json({
      message: "Name and email required",
      time: new Date().toLocaleString()
    });
  }

  const exists = users.find(u => u.email === email);
  if (exists) {
    return res.json({
      message: "Email already exists",
      time: new Date().toLocaleString()
    });
  }

  const newUser = { id: Date.now(), name, email };
  users.push(newUser);

  res.json({
    message: "User added",
    data: newUser,
    time: new Date().toLocaleString()
  });
});

// ----------- DELETE USER -----------
app.delete("/users/:id", (req, res) => {
  const id = parseInt(req.params.id);

  const index = users.findIndex(u => u.id === id);
  if (index === -1) {
    return res.json({
      message: "User not found",
      time: new Date().toLocaleString()
    });
  }

  users.splice(index, 1);

  res.json({
    message: "User deleted",
    time: new Date().toLocaleString()
  });
});

// ----------- BONUS: GET USER BY ID -----------
app.get("/users/:id", (req, res) => {
  const id = parseInt(req.params.id);

  const user = users.find(u => u.id === id);
  if (!user) {
    return res.json({
      message: "User not found",
      time: new Date().toLocaleString()
    });
  }

  res.json({
    message: "User found",
    data: user,
    time: new Date().toLocaleString()
  });
});

// ----------- LOGIN ROUTE -----------
app.post("/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.json({
      message: "All fields required",
      time: new Date().toLocaleString()
    });
  }

  if (email === "admin@gmail.com" && password === "1234") {
    return res.json({
      message: "Login Success",
      time: new Date().toLocaleString()
    });
  }

  res.json({
    message: "Invalid Credentials",
    time: new Date().toLocaleString()
  });
});

// ----------- START SERVER -----------
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});